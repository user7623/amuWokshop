//
//  majstorModel.swift
//  najdiSiMajstor
//
//  Created by iIdiot on 12/14/20.
//  Copyright © 2020 iIdiot. All rights reserved.
//

import Foundation


