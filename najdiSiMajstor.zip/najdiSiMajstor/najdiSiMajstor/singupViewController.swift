//
//  singupViewController.swift
//  najdiSiMajstor
//
//  Created by iIdiot on 12/12/20.
//  Copyright © 2020 iIdiot. All rights reserved.
//

import UIKit

class signupViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    
}
