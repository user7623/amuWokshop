//
//  ViewController.swift
//  najdiSiMajstor
//
//  Created by iIdiot on 12/12/20.
//  Copyright © 2020 iIdiot. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        errorLabel.isHidden = true
        
    }

    
    @IBOutlet var errorLabel: UILabel!
    
    
    @IBOutlet var usernameTextField: UITextField!
    
    
    @IBOutlet var passwordTextField: UITextField!
    
    //TODO: povrzi od novo so kopceto
    @IBAction func signInButton(_ sender: Any) {
        
        let user = usernameTextField!.text as! String
        let pass = passwordTextField!.text as! String
        
        if checkCredentials(user: user, pass: pass)
        {
            if isClient(user: user)
            {
                performSegue(withIdentifier: "toClientView", sender: self)
            }else{
                performSegue(withIdentifier: "toMajstorView", sender: self)
            }
        }else{
            errorLabel?.text = "Wrong username or password"
            errorLabel.isHidden = false
        }
    }
    
    func checkCredentials(user: String, pass: String) -> Bool
    {
        //dodadi kod za proverka
        return true
    }
    func isClient(user: String) -> Bool
    {
        //dodadi kod za da proveri dali e klient
        return true
    }
}

